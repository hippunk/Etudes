#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAILLE 256
#define D_MAX 999999.0

void AsynAmorcer();
void AsynInitialiser();
void AsynReconnaitre();
void AsynTester();
