void AsynAmorcer();
void AsynInitialiser();
void AsynReconnaitre();
void AsynTester(int nJeton);
