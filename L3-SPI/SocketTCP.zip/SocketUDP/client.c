#include "commun.h"

int main(int argc, char * argv[])
{
	struct sockaddr_in serv_addr,cli_addr; //structure d'adresse pour le bind
	int sockfd,recv_len, slen = sizeof(cli_addr);
	char buf[BUFLEN];

	unsigned int msg = 0; 
	
	//Variables pour le fichier
	FILE *fd;

	//Récupération des arguments
	if(argc != 4){
		
		printf("usage : <NomServeur> <NumPort> <NomFichier> \n");
		exit(-1);
	}

	int PORT = atoi(argv[2]);
	char srvname[BUFLEN];
	char nom[BUFLEN];
	strcpy(nom,argv[3]);
	strcpy(srvname,argv[1]);

	//Creation d'un socket UDP
	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		
		perror("Erreur de socket\n");
		exit(-1);
	}

	memset((char *)&cli_addr,0x0,sizeof(struct sockaddr_in));

	//Remplissage de la structure cli_addr
		cli_addr.sin_family = AF_INET;
		cli_addr.sin_port = htons(PORT);
		//cli_addr.sin_addr.s_addr = htonl(INADDR_ANY);
		
	struct hostent *hostinfo = NULL;

	/*if(inet_aton(srvname , &cli_addr.sin_addr) == 0)            // Create datagram with server IP and port.
	{
	    fprintf(stderr, "inet_aton() failed\n");
	    exit(1);
	}*/

	/*if(bind(sockfd, (struct sockaddr *)&cli_addr, sizeof(cli_addr)) < 0){
		perror("Erreur de bind\n");exit(-1);}*/
	
	//convertir l'ip du serveur en ip compréhensible pour les autres fonctions
	if((inet_aton(SERVEUR, &cli_addr.sin_addr)) < 0){

		perror("Erreur d'inet_aton\n");
		exit(-1);
	}
	
		/*Connection à la socket*/
	if(connect(sockfd,(struct sockaddr *) &cli_addr, sizeof(cli_addr)) < 0){
		perror("connect()");
		exit(-1);
	}
	
	//printf("saisir message : \n");
	memset(buf,'\0',BUFLEN);
	//fgets(buf,BUFLEN,stdin);	

	if((fd = fopen(nom, "r")) == NULL){
		
		perror("Pb ouverture fichier\n");
		exit(-1);
	}


	if((send(sockfd, &nom, BUFLEN, 0) < 0)) {
		
		perror("Erreur send\n");
		exit(-1);
	}
	
	int nbroctet = 0, nbrtotaloctet = 0;		//Entiers pour la reception du nombre d'octets reçu à chaque "tour" et le nombre total d'octets reçus

	do{

		msg = 0;
		nbroctet = fread(&msg, sizeof(int), 1, fd);
		printf("dans la boucle. Donnée : %u, nbOct : %i \n", msg, nbroctet);
		nbrtotaloctet += nbroctet;
		send(sockfd, &msg, sizeof(int), 0);
		
	}while(nbroctet != 0);

	send(sockfd, 0, 0, 0);

	close(sockfd);

	return EXIT_SUCCESS;
}
