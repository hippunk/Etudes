#include "commun.h"

int main(int argc, char * argv[])
{

	if(argc != 2){
		
		printf("usage : <NumPort>\n");
		exit(-1);
	}

	int PORT = atoi(argv[1]);

	struct sockaddr_in serv_addr,cli_addr; //structure d'adresse pour le bind
	int sockfd,recv_len, slen = sizeof(cli_addr);
	char buf[BUFLEN];
	
	//Variables pour le fichier
	FILE *fich;
	int fd, TAILLE;
	unsigned int msg = 0;

	//Creation d'un socket TCP
	if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		perror("Erreur de socket\n");exit(-1);}



	memset((char *)&serv_addr,0x0,sizeof(struct sockaddr_in));

	//Remplissage de la structure serv_addr
		serv_addr.sin_family = AF_INET;
		serv_addr.sin_port = htons(PORT);
		serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);


	if(bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0){
		perror("Erreur de bind\n");exit(-1);}

	memset(buf,'\0',BUFLEN);
	//Traitement pour socket UDP
		/*if((recv_len = recvfrom(sockfd, buf, BUFLEN,0,(struct sockaddr *)&cli_addr,&slen)) < 0){
			perror("Erreur de recvfrom\n");exit(-1);}
	
		strcat(buf,".srv");
		if((fich = fopen(buf, "wr")) == NULL){
			perror("Pb d'ouverture fichier : %s\n");
			exit(-1);
		}
	
		size_t nbroctet = 0, nbrtotaloctet = 0;
	
	do {						//Boucle de reception des données et d'écriture de ces données dans le fichier nom
		msg = 0;
		recv_len = recvfrom(sockfd, &msg, sizeof(int),0,(struct sockaddr *)&cli_addr,&slen);
		nbroctet = fwrite(&msg, sizeof(int), 1, fich);
		nbrtotaloctet += nbroctet;
		printf("Data : %u taille : %d, recv_len : %i\n", msg, nbroctet,recv_len);
	}while(recv_len != 0);

	printf("Taille totale reçue  : %d\n", nbrtotaloctet);*/
	
	
	listen(sockfd,1);

/* accept la connexion */
socklen_t addrlen = sizeof(cli_addr);
  int client_socket = accept(sockfd, (struct sockaddr *)&cli_addr, &addrlen);

	printf("Client connecté\n");
	
	if((recv( client_socket, &buf, BUFLEN,0)) < 0)
	{
		perror("Pb recv()");
		exit(-1);
	}

	
		strcat(buf,".srv");
		if((fich = fopen(buf, "wr")) == NULL){
			perror("Pb d'ouverture fichier : %s\n");
			exit(-1);
		}

		size_t nbroctet = 0, nbrtotaloctet = 0;
	
	do {						//Boucle de reception des données et d'écriture de ces données dans le fichier nom
		msg = 0;
		recv_len = recv(client_socket, &msg, sizeof(int),0);
		nbroctet = fwrite(&msg, sizeof(int), 1, fich);
		nbrtotaloctet += nbroctet;
		printf("Data : %u taille : %i, recv_len : %i\n", msg, nbroctet,recv_len);
	}while(recv_len != 0);


	//printf("\nData : %s\n", buf);

shutdown(sockfd,2);
	close(sockfd);

	return EXIT_SUCCESS;
}
