
//--------Client :
#define TAILLE 6*1024

int client(int argc,char *argv[]){

    int sockfd, addrIPpresse = 0;

    uchar buffer[TAILLE];
    
    addrIPpresse = atoi(argv[1]);
    
    //ouverture du fichier carac:
    FILE * fd_carac;

    if((fd_carac = fopen(argv[3], wr)) = NULL){
        perror("pb d'ouverture fichier caractéristique");
    }

    //Création de la socket :
    if((sockfd = socket(AF_INET, SOCK_DGRAM, AF_INET)) <0){
    }
    struct sockaddr cli_addr;

    //Lien à la socket

    if(bind(sockfd, (struct sockaddr*)&cli_addr, sizeof(cli_addr))< 0){

         perror("Impossible de bind le port");
         return -1;
    
    //parcours du fichier
    size_t nbroct;

    do{
        nbroct = fread(buffer, TAILLE, 1, fd_carac);
        sendto(sockfd, buffer, TAILLE, 0);
    }while (nbroct !=0);

    sendto(sockfd, "", 0, 0);

    //fermeture de la socket
    close(sockfd);

    //fermeture du fichier
    fclose(fd_carac);
}



//------Serveur :

int serveur (int argc, char *argv[]){

    int sockfd;
    uchar buff[TAILLE];

    //Ouverture d'un fichier local
    FILE * fd_local;
    if((fd_carac = fopen( fich_carac, rw)) = NULL){
    }

    //ouverture de la socket 
    sockfd = socket(AF_INET, SOCK_DGRAM, 0);

    struct sockaddr serv_addr, cli_addr;
    init serv_addr;
    init cli_addr;
    bind(sockfd, (strcut sock_addr*)&serv_addr, sizeof(serv_addr));

    size_t nbroct;

    do {
        recvfrom(sockfd, buff, TAILLE, 0);
        nbroct = fwrite(buff, TAILLE, 1, fd_local);
    }while (nbroct != 0);

    close(sockfd);
    fclose(fd_local);
}
