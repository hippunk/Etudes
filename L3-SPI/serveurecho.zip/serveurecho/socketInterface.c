#include "socketInterface.h"

int socketEnvoi(int sock, void * buff, size_t size)
{
	int taille = 0;
	//Envoi le nom de fichier au serveur
		if((taille = send(sock, buff, size, 0) < 0)) {
			perror("Erreur envoi\n");
			exit(-1);
		}
	return taille;
}

int socketReception(int sock, void * buff, size_t size)
{
	int taille = 0;
	//Envoi le message au serveur
		if((taille = recv( sock, buff, size,0)) < 0)
		{
			perror("Erreur reception");
			exit(-1);
		}
	return taille;
}



void socketEnvoiFichier(int sock, char nom[BUFLEN])
{

	unsigned char msg = '\0'; //Autre buffer pour récupération/envoi de message entiers par entiers 
	FILE *fd; //descripteur du fichier envoyé au serveur
	unsigned char fin = EOF;

	/*Recuperation du descripeur de fichier*/
		if((fd = fopen(nom, "r")) == NULL){
		
			perror("Pb ouverture fichier\n");
			exit(-1);
		}

	printf("nom : %s\n", nom);

	//Entiers pour la reception du bufbre d'octets reçu à chaque "tour"
		int nbroctet = 0;

	//Evoi du fichier entier par entier
		do{
			nbroctet = fread(&msg, sizeof(char), 1, fd); //lecture du fichier
			//printf("Donnée : %u, nbOct : %i \n", msg, nbroctet); //affichage de la donnée envoyée
			socketEnvoi(sock, &msg, sizeof(char));
		}while(nbroctet != 0); //envoi jusqu'a fin de fichier

		//printf("paquet vide");
		socketEnvoi(sock, &fin, sizeof(char));	//Paquet vide pour signaler la fin de l'envoi

		fclose(fd);
}

void socketReceptionFichier(int sock, char nom[BUFLEN])
{

	unsigned char msg = '\0'; //Autre buffer pour récupération/envoi de message entiers par entiers 
	FILE *fd; //descripteur du fichier envoyé au serveur
	//printf("nom fich %s\n",nom);
	unsigned char fin = EOF;

	//Creation du fichier	
		if((fd = fopen(nom, "wr")) == NULL){
			perror("Pb d'ouverture fichier");
			exit(-1);
		}

	//Entiers pour la reception du nombre d'octets reçu à chaque "tour"
		int nbroctet = 0;
	
	//Reception du fichier entier par entier
		do{
			recv(sock, &msg, sizeof(char),0); //reception des données
			if(msg != fin)
				nbroctet = fwrite(&msg, sizeof(char), 1, fd); //ecriture du fichier
			//printf("Data : %u taille : %i\n", msg, nbroctet); //affichage de la donnée recue
		}while(msg != fin); //Boucle jusqu'à réception du paquet vide
	//printf("fin\n");
	//fermeture du fichier
		fclose(fd);
}

int socketCreer()
{
	int sockfd;
	//Creation d'un socket TCP
		if((sockfd = socket(AF_INET, SOCK_STREAM, 0)) < 0) {
		
			perror("Erreur de socket\n");
			exit(-1);
		}

	//nettoyage contenu structure utilisées
		memset((char *)&cli_addr,0x0,sizeof(struct sockaddr_in));
		memset((char *)&serv_addr,0x0,sizeof(struct sockaddr_in));

	return sockfd;
}

void socketClientConnecter(int sockfd,char srvname[BUFLEN],int port)
{

	//Remplissage de la structure cli_addr
		cli_addr.sin_family = AF_INET;
		cli_addr.sin_port = htons(port);
		cli_addr.sin_addr.s_addr = inet_addr(srvname);
	
	/*Recuperation du descripeur du socket*/
		if(connect(sockfd,(struct sockaddr *) &cli_addr, sizeof(cli_addr)) < 0){
			perror("connect()");
			exit(-1);
		}
}

void socketServeurConnecter(int sockfd,int port,int N)
{
	//Remplissage de la structure serv_addr
		serv_addr.sin_family = AF_INET;
		serv_addr.sin_port = htons(port);
		serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);

	//bind du socket au serveur
		if(bind(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0){
			perror("Erreur de bind\n");
			exit(-1);
		}
	listen(sockfd,N);
}

int socketServeurAttenteClient(int sockfd)
{
	int sock_cli;
	socklen_t addrlen = sizeof(cli_addr);
	sock_cli = accept(sockfd, (struct sockaddr *)&cli_addr, &addrlen);
		
	printf("Client connecté\n");
	return sock_cli;
}


void socketFermer(int sockfd)
{
	//fermeture du socket
		close(sockfd);
}
