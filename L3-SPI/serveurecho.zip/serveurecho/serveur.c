#include "commun.h"
#include "serveur.h"
#include "socketInterface.c" 

int main(int argc, char * argv[])
{
	//Récupération des paramètres
		if(argc != 2){
		
			printf("usage : <NumPort>\n");
			exit(-1);
		}

	int port = atoi(argv[1]); //Port de connexion au socket
	int i = 0;

	int sock = socketCreer();
	socketServeurConnecter(sock,port,1);
	int sock_cli = socketServeurAttenteClient(sock);

	socketReception(sock_cli, &i, sizeof(int));
	printf("i : %i\n",i);	
	i = 46;
	socketEnvoi(sock, &i, sizeof(int));


	socketFermer(sock_cli);
	socketFermer(sock_cli);

	return EXIT_SUCCESS;
}
