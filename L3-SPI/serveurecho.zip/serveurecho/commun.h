#ifndef _COMMUN_H
#define _COMMUN_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define BUFLEN 512

typedef enum {ERREUR = -1, PRET, TERMINE, FIN}etat;

typedef struct requete{
    
     char donnees[BUFLEN];

}requete_t;

typedef struct reponse {

     etat statut;

}reponse_t;

#endif
