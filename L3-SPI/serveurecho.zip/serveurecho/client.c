#include "commun.h"
#include "client.h"
#include "socketInterface.c"
#include <time.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <unistd.h>

float temps()
{
	float temps;
	struct timeval act;
	static struct timeval old;
	gettimeofday(&act, NULL);
	temps = ((act.tv_sec * 1000000 + act.tv_usec)-(old.tv_sec*1000000 + old.tv_usec))/1000000.0;
	old = act;
	return temps;
}

int main(int argc, char * argv[])
{
	//Récupération des paramètres
		if(argc != 3){
		
			printf("usage : <NomServeur> <NumPort>\n");
			exit(-1);
		}

	int port = atoi(argv[2]); //Port de connexion au socket
	char srvname[BUFLEN];strcpy(srvname,argv[1]);  //Nom du serveur distant	


	int sock = socketCreer();
	socketClientConnecter(sock,srvname,port);
	srand(time(NULL));
	int i = 666;

	temps();
	socketEnvoi(sock, &i, sizeof(int));
	socketReception(sock, &i, sizeof(int));
	printf("i : %i\n",i);
	printf("temps : %f\n", temps());	



	socketFermer(sock);

	return EXIT_SUCCESS;
}
