#ifndef _SOCKETINTERFACE_H
#define _SOCKETINTERFACE_H

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <unistd.h>
#define BUFLEN 512

struct sockaddr_in serv_addr,cli_addr;

int socketEnvoi(int sock, void * buff, size_t taille);

int socketReception(int sock, void * buff, size_t taille);

void socketEnvoiFichier(int sock, char nom[BUFLEN]);
/*Envoie au socket le fichier dont le nom est contenu dans buf "char buf[BUFLEN]"*/
void socketReceptionFichier(int sock, char nom[BUFLEN]);
/*Receptionne un fichier depuis le socket, son nom est chargé dans buf "char buf[BUFLEN]"*/
int socketCreer();
/*Ouvre un socket dans une variable globale ""*/
void socketClientConnecter(int sockfd, char srvname[BUFLEN], int port);
/*Connecte le socket avec l'adresse du serveur et son port, les données sont stockées dans des variables globales "struct sockaddr_in serv_addr,cli_addr"*/
void socketServeurConnecter(int sockfd, int port,int N);

int socketServeurAttenteClient(int sockfd);

void socketFermer(int sock);
/*Ferme le socket*/

#endif
