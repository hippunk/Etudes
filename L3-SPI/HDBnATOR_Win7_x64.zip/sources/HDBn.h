#ifndef HDBn_H_INCLUDED
#define HDBn_H_INCLUDED

void data_saisie();
void data_init();
void HDBn(serie_t * const serie, const int n);
void polarite_reset(serie_t * const serie);
void serie_reset(serie_t * const serie);
void serie_init(serie_t * const serie);

#endif
