#ifndef OUTIL_H_INCLUDED
#define OUTIL_H_INCLUDED

void attendre(int nb_ms);
void loop(int nb_tours);
int b_while(int bExpression);
int int_rand(int min, int max);
int s_scanf(char *chaine, int longueur);

#endif
