toto(a,b).
toto(c,b).
