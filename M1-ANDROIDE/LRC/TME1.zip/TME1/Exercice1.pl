pere(pepin, charlemagne).
mere(berthe, charlemagne).
pere(david, arthur).
pere(yury, asya).
mere(anne-marie, arthur).
mere(galina, asya).
