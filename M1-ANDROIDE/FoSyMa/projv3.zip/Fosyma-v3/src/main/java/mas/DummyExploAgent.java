package mas;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Random;

import org.graphstream.graph.Node;

import env.Attribute;
import env.Environment;
import env.Environment.Couple;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;
import jade.core.behaviours.TickerBehaviour;
import jade.lang.acl.ACLMessage;


public class DummyExploAgent extends abstractAgent{


	/**
	 * This method is automatically called when "agent".start() is executed.
	 * Consider that Agent is launched for the first time. 
	 * 			1 set the agent attributes 
	 *	 		2 add the behaviours
	 *          
	 */
	protected void setup(){

		super.setup();

		//get the parameters given into the object[]
		final Object[] args = getArguments();
		if(args[0]!=null){
			realEnv = (Environment) args[0];
			realEnv.deployAgent(this.getLocalName());

		}else{
			System.out.println("Erreur lors du tranfert des parametres");
		}

		//Add the behaviours
		addBehaviour(new RandomWalkBehaviour(this,realEnv));

		System.out.println("the agent "+this.getLocalName()+ " is started");

	}

	/**
	 * This method is automatically called after doDelete()
	 */
	protected void takeDown(){

	}


	/**************************************
	 * 
	 * 
	 * 				BEHAVIOURS
	 * 
	 * 
	 **************************************/


	public class RandomWalkBehaviour extends TickerBehaviour{
		/**
		 * When an agent choose to move
		 *  
		 */
		private static final long serialVersionUID = 9088209402507795289L;

		private boolean finished=false;
		private Environment realEnv;

		public RandomWalkBehaviour (final Agent myagent,Environment realEnv) {
			super(myagent, 1000);
			//super(myagent);
			this.realEnv=realEnv;


		}

		@Override
		public void onTick() {
			String myPosition=getCurrentPosition();

			if (myPosition!=""){
				List<Couple<String,List<Attribute>>> lobs=observe(myPosition);
				System.out.println("lobs: "+lobs);

//				try {
//					System.out.println("Press a key to move to the next step agents");
//					System.in.read();
//				} catch (IOException e) {
//					// TODO Auto-generated catch block
//					e.printStackTrace();
//				}


				//list of attribute associated to the currentPosition
				List<Attribute> lattribute= lobs.get(0).getR();


				Boolean b=false;
				for(Attribute a:lattribute){
					switch (a) {
					case TREASURE:
						System.out.println("My current backpack capacity is:"+ getBackPackFreeSpace());
						System.out.println("Value of the treasure on the current position: "+a.getValue());
						System.out.println("The agent grabbed :"+pick());
						System.out.println("the remaining backpack capacity is: "+ getBackPackFreeSpace());
						b=true;
						break;

					default:
						break;
					}
				}
				//test
				if (b){
					List<Couple<String,List<Attribute>>> lobs2=observe(myPosition);
					System.out.println("lobs after picking "+lobs2);
				}


				Random r= new Random();

				int moveId=r.nextInt(lobs.size());
				move(myPosition, lobs.get(moveId).getL());
			}

		}

	}


}
